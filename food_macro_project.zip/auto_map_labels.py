# auto_map_labels.py (see earlier messages for full content)
print('Run auto_map_labels.py')
