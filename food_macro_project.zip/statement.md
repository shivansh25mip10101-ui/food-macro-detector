# Problem Statement
Users need quick, authoritative estimates of macronutrients (protein, fats, carbohydrates) for food items they eat. Manual lookup is slow and inconsistent. The Food Macro Detector combines image recognition and the USDA FoodData Central dataset to return macros per serving.
