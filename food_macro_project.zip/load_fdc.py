# load_fdc.py (see earlier messages for full content)
print('Run the load_fdc.py script provided in the project folder')
