# extract_macros.py (see earlier messages for full content)
print('Run extract_macros.py')
