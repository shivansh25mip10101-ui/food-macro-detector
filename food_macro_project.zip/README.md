# Food Macro Detector
Estimate protein, fat and carbohydrate for food items using USDA FoodData Central + image classifier.

## Features
- Local ingestion of USDA FoodData Central bulk data into SQLite
- Extract protein/fat/carbs per 100g and map classifier labels to FDC ids
- Transfer-learning training script (MobileNetV2) for food image classification
- Inference example and small Flask API skeleton to serve predictions
- Helpful utilities and mapping tools for course submission
