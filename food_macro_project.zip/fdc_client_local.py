# fdc_client_local.py (see earlier messages for full content)
print('Use this client to query macros')
