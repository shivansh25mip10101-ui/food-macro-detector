# app.py (Flask skeleton)
print('Run app.py to start Flask server')
